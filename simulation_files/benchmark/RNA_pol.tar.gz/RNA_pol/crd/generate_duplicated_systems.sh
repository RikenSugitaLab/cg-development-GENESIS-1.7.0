#!/bin/bash

GENESIS_CG_tool_path=~/GENESIS_CG_tool

${GENESIS_CG_tool_path}/tools/modeling/duplication_modeling/duplication_generator.jl -t ../pol2_cg.top -c pol2_cg.gro --nx 1 --ny 1 --nz 1 --xpadding 20 --ypadding 20 --zpadding 20 -o pol
${GENESIS_CG_tool_path}/tools/modeling/duplication_modeling/duplication_generator.jl -t ../pol2_cg.top -c pol2_cg.gro --nx 2 --ny 2 --nz 2 --xpadding 20 --ypadding 20 --zpadding 20 -o pol
${GENESIS_CG_tool_path}/tools/modeling/duplication_modeling/duplication_generator.jl -t ../pol2_cg.top -c pol2_cg.gro --nx 3 --ny 3 --nz 3 --xpadding 20 --ypadding 20 --zpadding 20 -o pol
${GENESIS_CG_tool_path}/tools/modeling/duplication_modeling/duplication_generator.jl -t ../pol2_cg.top -c pol2_cg.gro --nx 4 --ny 4 --nz 4 --xpadding 20 --ypadding 20 --zpadding 20 -o pol
${GENESIS_CG_tool_path}/tools/modeling/duplication_modeling/duplication_generator.jl -t ../pol2_cg.top -c pol2_cg.gro --nx 5 --ny 5 --nz 5 --xpadding 20 --ypadding 20 --zpadding 20 -o pol
${GENESIS_CG_tool_path}/tools/modeling/duplication_modeling/duplication_generator.jl -t ../pol2_cg.top -c pol2_cg.gro --nx 6 --ny 6 --nz 6 --xpadding 20 --ypadding 20 --zpadding 20 -o pol
${GENESIS_CG_tool_path}/tools/modeling/duplication_modeling/duplication_generator.jl -t ../pol2_cg.top -c pol2_cg.gro --nx 7 --ny 7 --nz 7 --xpadding 20 --ypadding 20 --zpadding 20 -o pol
${GENESIS_CG_tool_path}/tools/modeling/duplication_modeling/duplication_generator.jl -t ../pol2_cg.top -c pol2_cg.gro --nx 8 --ny 8 --nz 8 --xpadding 20 --ypadding 20 --zpadding 20 -o pol
${GENESIS_CG_tool_path}/tools/modeling/duplication_modeling/duplication_generator.jl -t ../pol2_cg.top -c pol2_cg.gro --nx 9 --ny 9 --nz 9 --xpadding 20 --ypadding 20 --zpadding 20 -o pol
${GENESIS_CG_tool_path}/tools/modeling/duplication_modeling/duplication_generator.jl -t ../pol2_cg.top -c pol2_cg.gro --nx 10 --ny 10 --nz 10 --xpadding 20 --ypadding 20 --zpadding 20 -o pol
